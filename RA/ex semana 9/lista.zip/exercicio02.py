i = 0
while i > 5:
    num = int(input("digite um número: "))
    print(num)
    i += 1