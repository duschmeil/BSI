num = int(input("Digite um número entre 1 e 10: "))

for i in range(0, 10):
    print(f"{i} x {num} = {(i + 1) * num}")