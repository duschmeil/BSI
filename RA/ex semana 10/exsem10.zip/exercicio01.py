for i in range(0, 50):
    print(i + 1)