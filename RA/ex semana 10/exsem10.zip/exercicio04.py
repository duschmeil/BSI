soma = 0

for i in range(0, 10):
    idade = int(input("Digite uma idade: "))
    soma = soma + idade

print(f"A média é {soma/10}")
