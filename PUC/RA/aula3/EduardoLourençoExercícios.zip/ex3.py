tempC = int(input("Quantos graus(C°) está agora? "))
tempF = (tempC * 9 / 5) + 32
print(tempF,"F°")