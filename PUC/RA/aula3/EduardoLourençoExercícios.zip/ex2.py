qntCarros = int(input("Quantos carros você quer alugar? "))
preco = qntCarros * 100
print("Você deverá pagar R$",preco)