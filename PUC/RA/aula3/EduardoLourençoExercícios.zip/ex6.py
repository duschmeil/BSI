precoKG = int(input("Qual o preço por KG? "))
quantidade = int(input("Quantos kilos você vai comprar? "))
precoFinal = precoKG * quantidade
print("Você deverá pagar R$",precoFinal)